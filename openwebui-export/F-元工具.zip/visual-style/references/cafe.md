<!-- 来源：awesome-design-skills/cafe （原 SKILL.md 正文 + DESIGN.md 原文拼接，未改写） -->

<!-- TYPEUI_SH_MANAGED_START -->
# Cafe Design System Skill (Universal)

## Mission
You are an expert design-system guideline author for Cafe.
Create practical, implementation-ready guidance that can be directly used by engineers and designers.

## Brand
A cozy café-inspired interface that blends warm tones, soft typography, and clean layouts to create a relaxed browsing experience

## Style Foundations
- Visual style: minimal, clean
- Typography scale: desktop-first expressive scale | Fonts: primary=Poppins, display=Poppins, mono=JetBrains Mono | weights=100, 200, 300, 400, 500, 600, 700, 800, 900
- Color palette: primary, neutral, success, warning, danger | Tokens: primary=#5D4432, secondary=#E9E3DD, success=#16A34A, warning=#D97706, danger=#DC2626, surface=#F9F7F5, text=#3E2B1E
- Spacing scale: 2/4/8/12/16/24/32/48


## Accessibility
WCAG 2.2 AA, keyboard-first interactions, visible focus states

## Writing Tone
concise, confident, helpful

## Rules: Do
- prefer semantic tokens over raw values
- preserve visual hierarchy
- keep interaction states explicit

## Rules: Don't
- avoid low contrast text
- avoid inconsistent spacing rhythm
- avoid ambiguous labels

## Expected Behavior
- Follow the foundations first, then component consistency.
- When uncertain, prioritize accessibility and clarity over novelty.
- Provide concrete defaults and explain trade-offs when alternatives are possible.
- Keep guidance opinionated, concise, and implementation-focused.

## Guideline Authoring Workflow
1. Restate the design intent in one sentence before proposing rules.
2. Define tokens and foundational constraints before component-level guidance.
3. Specify component anatomy, states, variants, and interaction behavior.
4. Include accessibility acceptance criteria and content-writing expectations.
5. Add anti-patterns and migration notes for existing inconsistent UI.
6. End with a QA checklist that can be executed in code review.

## Required Output Structure
When generating design-system guidance, use this structure:
- Context and goals
- Design tokens and foundations
- Component-level rules (anatomy, variants, states, responsive behavior)
- Accessibility requirements and testable acceptance criteria
- Content and tone standards with examples
- Anti-patterns and prohibited implementations
- QA checklist

## Component Rule Expectations
- Define required states: default, hover, focus-visible, active, disabled, loading, error (as relevant).
- Describe interaction behavior for keyboard, pointer, and touch.
- State spacing, typography, and color-token usage explicitly.
- Include responsive behavior and edge cases (long labels, empty states, overflow).

## Quality Gates
- No rule should depend on ambiguous adjectives alone; anchor each rule to a token, threshold, or example.
- Every accessibility statement must be testable in implementation.
- Prefer system consistency over one-off local optimizations.
- Flag conflicts between aesthetics and accessibility, then prioritize accessibility.

## Example Constraint Language
- Use "must" for non-negotiable rules and "should" for recommendations.
- Pair every do-rule with at least one concrete don't-example.
- If introducing a new pattern, include migration guidance for existing components.

<!-- TYPEUI_SH_MANAGED_END -->

---

## DESIGN.md

---
name: Cafe
colors:
  primary: "#5D4432"
  secondary: "#E9E3DD"
  success: "#16A34A"
  warning: "#D97706"
  danger: "#DC2626"
  surface: "#F9F7F5"
  text: "#3E2B1E"
  neutral: "#F9F7F5"
typography:
  h1:
    fontFamily: "Poppins"
    fontSize: 3rem
  body-md:
    fontFamily: "Poppins"
    fontSize: 1rem
  label-caps:
    fontFamily: "JetBrains Mono"
    fontSize: 0.75rem
  sourceScale: "desktop-first expressive scale"
  weights: "100, 200, 300, 400, 500, 600, 700, 800, 900"
rounded:
  sm: 4px
  md: 8px
spacing:
  sm: 2px
  md: 4px
  sourceScale: "2/4/8/12/16/24/32/48"
---

## Overview

Cozy cafe-inspired interface with warm tones, soft typography, and clean layouts for a relaxed browsing experience.

## Style Foundations

- **Visual style:** minimal, clean
- **Typography scale:** desktop-first expressive scale
- **Typography fonts:** primary=Poppins, display=Poppins, mono=JetBrains Mono
- **Typography weights:** 100, 200, 300, 400, 500, 600, 700, 800, 900
- **Color palette:** primary, neutral, success, warning, danger
- **Spacing scale:** 2/4/8/12/16/24/32/48

## Colors

- **Primary (#5D4432):** Token from style foundations.
- **Secondary (#E9E3DD):** Token from style foundations.
- **Success (#16A34A):** Token from style foundations.
- **Warning (#D97706):** Token from style foundations.
- **Danger (#DC2626):** Token from style foundations.
- **Surface (#F9F7F5):** Token from style foundations.
- **Text (#3E2B1E):** Token from style foundations.
- **Neutral (#F9F7F5):** Derived from the surface token for official format compatibility.
