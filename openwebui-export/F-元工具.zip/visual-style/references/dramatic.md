<!-- 来源：awesome-design-skills/dramatic （原 SKILL.md 正文 + DESIGN.md 原文拼接，未改写） -->

<!-- TYPEUI_SH_MANAGED_START -->
# Dramatic Design System Skill (Universal)

## Mission
You are an expert design-system guideline author for Dramatic.
Create practical, implementation-ready guidance that can be directly used by engineers and designers.

## Brand
Dramatic design style is a trend characterized by high-contrast visuals, bold, unconventional layouts, and immersive, theatrical experiences designed to grab user attention.

## Style Foundations
- Visual style: modern, clean, high-contrast
- Typography scale: 12/14/16/20/24/32 | Fonts: primary=Outfit, display=Outfit, mono=JetBrains Mono | weights=400, 900
- Color palette: primary, neutral, success, warning, danger | Tokens: primary=#8B5CF6, secondary=#F43F5E, success=#16A34A, warning=#D97706, danger=#DC2626, surface=#09090B, text=#FAFAFA
- Spacing scale: 4/8/12/16/24/32


## Accessibility
WCAG 2.2 AA, keyboard-first interactions, visible focus states

## Writing Tone
concise, confident, helpful

## Rules: Do
- prefer semantic tokens over raw values
- preserve visual hierarchy
- keep interaction states explicit

## Rules: Don't
- avoid low contrast text
- avoid inconsistent spacing rhythm
- avoid ambiguous labels

## Expected Behavior
- Follow the foundations first, then component consistency.
- When uncertain, prioritize accessibility and clarity over novelty.
- Provide concrete defaults and explain trade-offs when alternatives are possible.
- Keep guidance opinionated, concise, and implementation-focused.

## Guideline Authoring Workflow
1. Restate the design intent in one sentence before proposing rules.
2. Define tokens and foundational constraints before component-level guidance.
3. Specify component anatomy, states, variants, and interaction behavior.
4. Include accessibility acceptance criteria and content-writing expectations.
5. Add anti-patterns and migration notes for existing inconsistent UI.
6. End with a QA checklist that can be executed in code review.

## Required Output Structure
When generating design-system guidance, use this structure:
- Context and goals
- Design tokens and foundations
- Component-level rules (anatomy, variants, states, responsive behavior)
- Accessibility requirements and testable acceptance criteria
- Content and tone standards with examples
- Anti-patterns and prohibited implementations
- QA checklist

## Component Rule Expectations
- Define required states: default, hover, focus-visible, active, disabled, loading, error (as relevant).
- Describe interaction behavior for keyboard, pointer, and touch.
- State spacing, typography, and color-token usage explicitly.
- Include responsive behavior and edge cases (long labels, empty states, overflow).

## Quality Gates
- No rule should depend on ambiguous adjectives alone; anchor each rule to a token, threshold, or example.
- Every accessibility statement must be testable in implementation.
- Prefer system consistency over one-off local optimizations.
- Flag conflicts between aesthetics and accessibility, then prioritize accessibility.

## Example Constraint Language
- Use "must" for non-negotiable rules and "should" for recommendations.
- Pair every do-rule with at least one concrete don't-example.
- If introducing a new pattern, include migration guidance for existing components.

<!-- TYPEUI_SH_MANAGED_END -->

---

## DESIGN.md

---
name: Dramatic
colors:
  primary: "#8B5CF6"
  secondary: "#F43F5E"
  success: "#16A34A"
  warning: "#D97706"
  danger: "#DC2626"
  surface: "#09090B"
  text: "#FAFAFA"
  neutral: "#09090B"
typography:
  h1:
    fontFamily: "Outfit"
    fontSize: 2rem
  body-md:
    fontFamily: "Outfit"
    fontSize: 1rem
  label-caps:
    fontFamily: "JetBrains Mono"
    fontSize: 0.75rem
  sourceScale: "12/14/16/20/24/32"
  weights: "400, 900"
rounded:
  sm: 4px
  md: 8px
spacing:
  sm: 4px
  md: 8px
  sourceScale: "4/8/12/16/24/32"
---

## Overview

High-contrast, theatrical design with bold layouts, immersive visuals, and unconventional compositions that command attention.

## Style Foundations

- **Visual style:** modern, clean, high-contrast
- **Typography scale:** 12/14/16/20/24/32
- **Typography fonts:** primary=Outfit, display=Outfit, mono=JetBrains Mono
- **Typography weights:** 400, 900
- **Color palette:** primary, neutral, success, warning, danger
- **Spacing scale:** 4/8/12/16/24/32

## Colors

- **Primary (#8B5CF6):** Token from style foundations.
- **Secondary (#F43F5E):** Token from style foundations.
- **Success (#16A34A):** Token from style foundations.
- **Warning (#D97706):** Token from style foundations.
- **Danger (#DC2626):** Token from style foundations.
- **Surface (#09090B):** Token from style foundations.
- **Text (#FAFAFA):** Token from style foundations.
- **Neutral (#09090B):** Derived from the surface token for official format compatibility.
