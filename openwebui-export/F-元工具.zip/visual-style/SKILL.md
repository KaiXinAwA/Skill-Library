---
name: visual-style
description: 按名字套用一种具体视觉风格（67 种预设，如 brutalist / glassmorphism / retro / pacman）。用户点名风格或要求"换成 X 风格"时使用；不用于通用 UI 设计、组件实现或版式规划。
---

# 视觉风格预设（67 种）

同一件事的 67 种做法，收在这一处。**用户点名哪个风格，就读哪一份，一次只读一份，不预读。**

## 用法

1. 从下面路由表找到用户要的风格（用户没说风格时，先按项目气质挑 2–3 个候选让人选，不要自作主张）。
2. 只打开对应 `references/<风格>.md`：前半是风格规则（typography / 配色 / 间距 / 组件处理），后半 `DESIGN.md` 是可直接落地的设计令牌与页面规范。
3. 落地产出仍走通用设计技能（版面结构、组件、可访问性不在本技能内）。

## 边界

- 不用于通用 UI 设计、组件库选型、页面结构与交互流程 → 走 `doubao-ui-design` / `ui-styling` / `design-system`。
- 不用于"帮我设计得好看点"这种没有风格指向的需求。
- 一个页面只用一种风格，混搭要先说明冲突点。

## 路由表

| 风格 | 气质 | 读哪份 |
|---|---|---|
| `agentic` | Conversational AI-first interface with… | `references/agentic.md` |
| `ant` | Structured, enterprise-focused design… | `references/ant.md` |
| `artistic` | High-contrast, expressive style with… | `references/artistic.md` |
| `basic` | Print-inspired visual language for books… | `references/basic.md` |
| `bento` | Modular grid layout with card-like blocks… | `references/bento.md` |
| `bold` | Strong visual presence with heavyweight… | `references/bold.md` |
| `brutalism` | Raw, anti-design aesthetic inspired by… | `references/brutalism.md` |
| `cafe` | Cozy cafe-inspired interface with warm… | `references/cafe.md` |
| `claude` | A research-journal aesthetic printed on… | `references/claude.md` |
| `claymorphism` | Soft, rounded 3D-like shapes mimicking… | `references/claymorphism.md` |
| `clean` | Simplicity-focused design with ample… | `references/clean.md` |
| `codex` | A radically minimal, blank-canvas interface… | `references/codex.md` |
| `colorful` | Vibrant, high-contrast palettes and… | `references/colorful.md` |
| `contemporary` | Current-era minimalist design with bento… | `references/contemporary.md` |
| `corporate` | Professional, brand-aligned design with… | `references/corporate.md` |
| `cosmic` | Futuristic sci-fi aesthetic with dark… | `references/cosmic.md` |
| `creative` | Playful, character-driven design with… | `references/creative.md` |
| `dithered` | Dot-pattern rendering technique that… | `references/dithered.md` |
| `doodle` | Hand-drawn, sketch-like style with doodles… | `references/doodle.md` |
| `dramatic` | High-contrast, theatrical design with bold… | `references/dramatic.md` |
| `editorial` | Magazine-inspired editorial layout with… | `references/editorial.md` |
| `enterprise` | Dark-themed cloud-platform aesthetic with… | `references/enterprise.md` |
| `expressive` | Vibrant, personality-driven design with… | `references/expressive.md` |
| `fantasy` | Game-inspired fantasy aesthetic with bold… | `references/fantasy.md` |
| `fiction` | A playful, energetic, cartoonesque… | `references/fiction.md` |
| `flat` | Two-dimensional minimalist style with… | `references/flat.md` |
| `friendly` | Approachable, intuitive design with rounded… | `references/friendly.md` |
| `futuristic` | Forward-looking design with tech-inspired… | `references/futuristic.md` |
| `geometric` | Geometric, structured design with clean… | `references/geometric.md` |
| `glassmorphism` | Frosted glass effect with translucent… | `references/glassmorphism.md` |
| `gradient` | Smooth color transitions and gradient-rich… | `references/gradient.md` |
| `immersive` | An immersive, interactive, exhibit-style… | `references/immersive.md` |
| `impeccable` | A modern, graphic, editorial-poster… | `references/impeccable.md` |
| `levels` | Conversion-focused design that removes… | `references/levels.md` |
| `lingo` | Playful, minimal design with bright colors… | `references/lingo.md` |
| `material` | Google's Material Design with layered… | `references/material.md` |
| `matrix` | A cyber-slick, dark-only Matrix-inspired… | `references/matrix.md` |
| `minimal` | Stripped-back design emphasizing… | `references/minimal.md` |
| `modern` | Contemporary editorial style with serif… | `references/modern.md` |
| `mono` | Monospace-driven, matrix-inspired design… | `references/mono.md` |
| `neobrutalism` | Modern take on brutalism with bold borders… | `references/neobrutalism.md` |
| `neon` | Electric neon glow effects with… | `references/neon.md` |
| `neumorphism` | Soft, extruded UI elements with inner and… | `references/neumorphism.md` |
| `pacman` | Retro arcade-inspired design with pixel… | `references/pacman.md` |
| `paper` | Paper-textured, print-inspired design with… | `references/paper.md` |
| `perspective` | Spatial depth design with isometric views… | `references/perspective.md` |
| `power` | High-end dark aesthetic with bold headings… | `references/power.md` |
| `premium` | Apple-inspired premium aesthetic with… | `references/premium.md` |
| `professional` | Polished, business-ready design with modern… | `references/professional.md` |
| `pulse` | Dynamic, vibrant style with thick borders… | `references/pulse.md` |
| `refined` | Carefully curated, modern minimal style… | `references/refined.md` |
| `retro` | Throwback design with vintage-inspired… | `references/retro.md` |
| `riso` | A playful, joyful, two-color risograph… | `references/riso.md` |
| `roku` | App dashboard with purple-themed aesthetic… | `references/roku.md` |
| `sega` | A playful, arcade-inspired interface for… | `references/sega.md` |
| `shadcn` | Shadcn/ui-inspired design with minimal… | `references/shadcn.md` |
| `sketch` | A friendly, hand-drawn sketch interface… | `references/sketch.md` |
| `skeumorphism` | Real-world mimicry with textured surfaces… | `references/skeumorphism.md` |
| `sleek` | Modern minimalist aesthetic with clean… | `references/sleek.md` |
| `spacious` | Generous whitespace, consistent padding… | `references/spacious.md` |
| `square` | Graceful, refined aesthetic with delicate… | `references/square.md` |
| `stitch` | Clean, high-contrast enterprise design for… | `references/stitch.md` |
| `storytelling` | Narrative-driven design using visuals… | `references/storytelling.md` |
| `terracotta` | A sun-baked, clay-toned editorial interface… | `references/terracotta.md` |
| `tetris` | Classic block-game inspired design with… | `references/tetris.md` |
| `vibrant` | Lively, colorful design with bold playful… | `references/vibrant.md` |
| `vintage` | 1950s-1990s nostalgia with skeuomorphic… | `references/vintage.md` |
