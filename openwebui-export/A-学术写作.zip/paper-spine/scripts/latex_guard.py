#!/usr/bin/env python3
"""Guard checks for LaTeX manuscripts.

This is not a replacement for compilation. It catches common structural issues
early so prose revision does not silently damage labels, citations, figures, or
environments.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

GRAPHIC_EXTENSIONS = [".pdf", ".png", ".jpg", ".jpeg", ".eps", ".tif", ".tiff"]


@dataclass
class Finding:
    severity: str
    check: str
    message: str
    line: int | None = None


def read_text(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="replace")


def strip_comments(text: str) -> str:
    lines = []
    for line in text.splitlines():
        cut = None
        for match in re.finditer(r"(?<!\\)%", line):
            cut = match.start()
            break
        lines.append(line if cut is None else line[:cut])
    return "\n".join(lines)


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def parse_bib_keys(path: Path | None) -> set[str]:
    if not path:
        return set()
    text = read_text(path)
    return set(re.findall(r"@\w+\s*\{\s*([^,\s]+)", text))


def check_document_markers(text: str) -> list[Finding]:
    findings: list[Finding] = []
    if "\\begin{document}" not in text:
        findings.append(Finding("error", "document", "Missing \\begin{document}."))
    if "\\end{document}" not in text:
        findings.append(Finding("error", "document", "Missing \\end{document}."))
    return findings


def check_serialized_commands(text: str) -> list[Finding]:
    """Reject JSON/Python-escaped TeX before any renderer sees it.

    A source line beginning with two literal backslashes (for example
    ``\\\\documentclass``) is serialized command text, not a LaTeX command.
    Treating it as a manuscript can produce a perfectly valid-looking PDF that
    merely prints the source, so this is a hard source-generation failure.
    """
    pattern = re.compile(
        r"(?m)^\s*\\\\(?:documentclass|usepackage|RequirePackage|begin|end|section|subsection|title|author|date|maketitle)\b"
    )
    findings: list[Finding] = []
    for match in pattern.finditer(text):
        findings.append(
            Finding(
                "error",
                "serialized-command",
                "LaTeX source contains a serialized command with two leading backslashes; regenerate the source with one leading backslash.",
                line_number(text, match.start()),
            )
        )
    return findings


def check_merge_markers(text: str) -> list[Finding]:
    findings: list[Finding] = []
    for marker in ("<<<<<<<", "=======", ">>>>>>>"):
        index = text.find(marker)
        if index >= 0:
            findings.append(
                Finding("error", "merge-marker", f"Found merge/conflict marker {marker}.", line_number(text, index))
            )
    return findings


def check_braces(text: str) -> list[Finding]:
    findings: list[Finding] = []
    stack: list[tuple[str, int]] = []
    for match in re.finditer(r"(?<!\\)[{}]", text):
        token = match.group(0)
        if token == "{":
            stack.append((token, line_number(text, match.start())))
        elif stack:
            stack.pop()
        else:
            findings.append(Finding("error", "braces", "Closing brace without matching opening brace.", line_number(text, match.start())))
    for _, line in stack[-10:]:
        findings.append(Finding("error", "braces", "Opening brace without matching closing brace.", line))
    return findings


def check_environments(text: str) -> list[Finding]:
    findings: list[Finding] = []
    stack: list[tuple[str, int]] = []
    for match in re.finditer(r"\\(begin|end)\{([^{}]+)\}", text):
        action, env = match.group(1), match.group(2)
        line = line_number(text, match.start())
        if action == "begin":
            stack.append((env, line))
            continue
        if not stack:
            findings.append(Finding("error", "environment", f"\\end{{{env}}} has no matching begin.", line))
            continue
        last_env, last_line = stack.pop()
        if last_env != env:
            findings.append(
                Finding(
                    "error",
                    "environment",
                    f"\\end{{{env}}} closes \\begin{{{last_env}}} from line {last_line}.",
                    line,
                )
            )
    for env, line in stack[-10:]:
        findings.append(Finding("error", "environment", f"\\begin{{{env}}} is not closed.", line))
    return findings


def check_labels_and_refs(text: str) -> list[Finding]:
    findings: list[Finding] = []
    labels: dict[str, int] = {}
    for match in re.finditer(r"\\label\{([^{}]+)\}", text):
        key = match.group(1)
        line = line_number(text, match.start())
        if key in labels:
            findings.append(Finding("error", "label", f"Duplicate label `{key}` also defined at line {labels[key]}.", line))
        else:
            labels[key] = line

    ref_pattern = re.compile(r"\\(?:ref|autoref|cref|Cref|eqref)\{([^{}]+)\}")
    for match in ref_pattern.finditer(text):
        keys = [item.strip() for item in match.group(1).split(",") if item.strip()]
        for key in keys:
            if key not in labels:
                findings.append(Finding("warning", "reference", f"Reference `{key}` has no matching label.", line_number(text, match.start())))
    return findings


def check_citations(text: str, bib_keys: set[str], bib_was_provided: bool) -> list[Finding]:
    findings: list[Finding] = []
    cite_pattern = re.compile(r"\\cite\w*\*?(?:\[[^\]]*\]){0,2}\{([^{}]+)\}")
    used: set[str] = set()
    for match in cite_pattern.finditer(text):
        if re.search(r"\\(?:New|Renew|Provide|Declare)DocumentCommand\s*$", text[:match.start()]):
            continue
        keys = [item.strip() for item in match.group(1).split(",") if item.strip()]
        # Pandoc citeproc uses ref-<BibTeX key> and emits matching bibitems.
        # Keep all ordinary citation checks and verify those destinations below.
        if match.group(0).startswith("\\citeproc{"):
            keys = [key.removeprefix("ref-") for key in keys]
        used.update(keys)
        if bib_was_provided:
            for key in keys:
                if "#" in key:
                    continue
                if key not in bib_keys:
                    findings.append(Finding("error", "citation", f"Citation key `{key}` not found in BibTeX file.", line_number(text, match.start())))
    if used and not bib_was_provided:
        findings.append(Finding("warning", "citation", "Citations found, but no --bib file was provided."))
    return findings


def check_internal_destinations(text: str) -> list[Finding]:
    """Validate concrete TeX link destinations, including Pandoc citeproc."""
    findings: list[Finding] = []
    bibitems = set(re.findall(r"\\bibitem(?:\[[^\]]*\])?\{([^{}]+)\}", text))
    hypertargets = set(re.findall(r"\\hypertarget\{([^{}]+)\}", text))
    for match in re.finditer(r"\\(citeproc|hyperlink)\{([^{}]+)\}", text):
        if re.search(r"\\(?:New|Renew|Provide|Declare)DocumentCommand\s*$", text[:match.start()]):
            continue
        kind, key = match.groups()
        if "#" in key:  # macro parameters, not document references
            continue
        destinations = bibitems if kind == "citeproc" else hypertargets
        if key not in destinations:
            findings.append(Finding("error", "link-destination", f"\\{kind} destination `{key}` is missing.", line_number(text, match.start())))
    for match in re.finditer(r"\b(Figure|Table)(?:~|\s)+\\ref\{((?:fig|tbl):[^{}]+)\}", text):
        kind, key = match.groups()
        if not key.startswith("fig:" if kind == "Figure" else "tbl:"):
            findings.append(Finding("error", "link-destination", f"{kind} reference points to wrong-kind destination `{key}`.", line_number(text, match.start())))
    return findings


def mask_citeproc_text(text: str) -> str:
    """CSL owns the rendered text inside citeproc, not the legacy numeric rule."""
    pattern = re.compile(r"\\citeproc\{[^{}]+\}\{")
    for match in reversed(list(pattern.finditer(text))):
        depth, end = 1, match.end()
        while end < len(text) and depth:
            if text[end] in "{}" and (end == 0 or text[end - 1] != "\\"):
                depth += 1 if text[end] == "{" else -1
            end += 1
        if depth == 0:
            text = text[:match.start()] + " " * (end - match.start()) + text[end:]
    return text


def graphic_paths(text: str, tex_dir: Path) -> list[Path]:
    paths = [tex_dir]
    match = re.search(r"\\graphicspath\{((?:\{[^{}]+\})+)\}", text, flags=re.DOTALL)
    if not match:
        return paths
    for item in re.findall(r"\{([^{}]+)\}", match.group(1)):
        paths.append((tex_dir / item).resolve())
    return paths


def graphic_exists(name: str, roots: list[Path]) -> bool:
    candidate = Path(name)
    names = [candidate] if candidate.suffix else [Path(str(candidate) + ext) for ext in GRAPHIC_EXTENSIONS]
    for root in roots:
        for item in names:
            if (root / item).exists():
                return True
    return False


def check_graphics(text: str, tex_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    roots = graphic_paths(text, tex_path.parent)
    pattern = re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^{}]+)\}")
    for match in pattern.finditer(text):
        name = match.group(1)
        if not graphic_exists(name, roots):
            findings.append(Finding("warning", "graphics", f"Graphic `{name}` was not found relative to known graphic paths.", line_number(text, match.start())))
    return findings


def check_placeholders(text: str) -> list[Finding]:
    findings: list[Finding] = []
    for pattern in (r"\[NEED DATA:[^\]]*\]", r"\[NEED CITATION:[^\]]*\]", r"TODO", r"FIXME"):
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            findings.append(Finding("warning", "placeholder", f"Placeholder remains: {match.group(0)}", line_number(text, match.start())))
    return findings


def check_alignment_tabs(text: str) -> list[Finding]:
    findings: list[Finding] = []
    math_or_table_envs = {
        "align",
        "align*",
        "array",
        "tabular",
        "tabularx",
        "matrix",
        "pmatrix",
        "bmatrix",
        "cases",
        "split",
    }
    stack: list[str] = []
    for number, line in enumerate(text.splitlines(), start=1):
        for match in re.finditer(r"\\(begin|end)\{([^{}]+)\}", line):
            if match.group(1) == "begin":
                stack.append(match.group(2))
            elif stack:
                stack.pop()
        if "&" in line and r"\&" not in line:
            active = set(stack)
            if not active.intersection(math_or_table_envs):
                findings.append(Finding("warning", "special-char", "Unescaped `&` may break LaTeX outside tables/math.", number))
    return findings


def check_title_and_maketitle(text: str) -> list[Finding]:
    findings: list[Finding] = []
    if "\\title{" not in text:
        findings.append(Finding("error", "title", "Missing \\title{...}. Paper title is required."))
    if "\\maketitle" not in text:
        findings.append(Finding("error", "title", "Missing \\maketitle. Title page/heading is required."))
    return findings


def check_citation_format(text: str, style: str = "venue") -> list[Finding]:
    # A raw author-year marker is not evidence that the venue requires brackets.
    # Linkage and bibliographic checks remain independent of visible style.
    if style != "numeric-brackets":
        return []
    findings: list[Finding] = []
    doc_start = text.find("\\begin{document}")
    if doc_start == -1:
        return findings
    body = mask_citeproc_text(text[doc_start:])
    # Pandoc duplicates the caption as plain accessibility alt text. Its
    # citation spelling is not an additional unlinked prose citation.
    body = re.sub(r"\\includegraphics\[[^\]]*\]", lambda match: re.sub(r"[^\n]", " ", match.group(0)), body)

    # Remove math mode spans so we don't flag brackets inside math.
    body_no_math = re.sub(r"\$\$.*?\$\$", " ", body, flags=re.DOTALL)
    body_no_math = re.sub(r"\\\[.*?\\\]", " ", body_no_math, flags=re.DOTALL)
    body_no_math = re.sub(r"\$[^$]*?\$", " ", body_no_math)

    # Find parenthesized bracket citations: ([15]), ([3,12]).
    # Plain [1] / [3,12,13] is the required style.
    paren_pattern = re.compile(r"\(\[\d+(?:\s*[,–-]\s*\d+)*\]\)")
    for match in paren_pattern.finditer(body_no_math):
        line = line_number(text, doc_start + match.start())
        findings.append(Finding(
            "error", "citation-format",
            f"Parenthesized citation {match.group(0)} should be plain square-bracket numeric style, e.g. [1].",
            line,
        ))

    # Find rendered author-year citations: (Smith, 2020), (Jones and Lee, 2021),
    # (Brown et al., 2019). The hard rule is plain numeric [1]; author-year is
    # forbidden. Require a comma before the year so prose like "(see Section 2)"
    # or "(in 2020)" is not flagged.
    author_year_pattern = re.compile(
        r"\(\s*[A-Z][A-Za-z.'’\-]+"
        r"(?:\s+et\s+al\.?|\s+and\s+[A-Z][A-Za-z.'’\-]+|\s*&\s*[A-Z][A-Za-z.'’\-]+)?"
        r",\s*\d{4}[a-z]?\s*\)"
    )
    for match in author_year_pattern.finditer(body_no_math):
        line = line_number(text, doc_start + match.start())
        findings.append(Finding(
            "error", "citation-format",
            f"Author-year citation {match.group(0).strip()} is not allowed. Use plain "
            "square-bracket numeric citations, e.g. [1].",
            line,
        ))

    return findings


def check_citation_linkage(text: str, bib_keys: set[str]) -> list[Finding]:
    """Catch in-text citations that are inert text instead of linked references.

    A numeric bibliographystyle still renders ``\\cite{key}`` as ``[1]``, so the
    visible plain-numeric style is preserved; what this check forbids is typing
    the bracket number as literal text with no ``\\cite`` behind it, which leaves
    the citation unlinked to the reference list in both the PDF and the .docx.
    """
    findings: list[Finding] = []
    doc_start = text.find("\\begin{document}")
    if doc_start == -1:
        return findings
    body = text[doc_start:]

    # In-text citations live before the reference list itself.
    bib_match = re.search(r"\\begin\{thebibliography\}|\\bibliography\b", body)
    intext = body[: bib_match.start()] if bib_match else body

    # Drop math so bracketed numbers inside math are not read as citations.
    intext_no_math = re.sub(r"\$\$.*?\$\$", " ", intext, flags=re.DOTALL)
    intext_no_math = re.sub(r"\\\[.*?\\\]", " ", intext_no_math, flags=re.DOTALL)
    intext_no_math = re.sub(r"\$[^$]*?\$", " ", intext_no_math)

    cite_macros = re.findall(r"\\cite\w*\*?(?:\[[^\]]*\]){0,2}\{([^{}]+)\}", body)
    literal_pattern = re.compile(r"(?<!\w)\[\d+(?:\s*[,–-]\s*\d+)*\]")
    literal_marks = list(literal_pattern.finditer(intext_no_math))
    bibitem_keys = re.findall(r"\\bibitem(?:\[[^\]]*\])?\{([^{}]+)\}", body)
    entry_count = len(bibitem_keys) or len(bib_keys)

    if literal_marks and not cite_macros:
        loc = literal_pattern.search(intext)
        line = line_number(text, doc_start + loc.start()) if loc else None
        findings.append(Finding(
            "error", "citation-linkage",
            f"In-text citations use literal bracket numbers (e.g. {literal_marks[0].group(0)}) "
            "with no \\cite command, so they are inert text with no link to the reference list. "
            "Cite with \\cite{key} backed by a numeric bibliographystyle or \\bibitem entries; a "
            "numeric style still renders as [1].",
            line,
        ))
        numbers = [int(value) for match in literal_marks for value in re.findall(r"\d+", match.group(0))]
        if entry_count and numbers and max(numbers) > entry_count:
            findings.append(Finding(
                "error", "citation-linkage",
                f"Highest in-text citation number [{max(numbers)}] exceeds the {entry_count} "
                "reference entries; the manual numbering is out of sync with the bibliography.",
            ))
    elif cite_macros and bibitem_keys:
        used = {key.strip() for group in cite_macros for key in group.split(",") if key.strip()}
        uncited = [key for key in bibitem_keys if key not in used]
        if uncited:
            sample = ", ".join(uncited[:5])
            findings.append(Finding(
                "warning", "citation-linkage",
                f"{len(uncited)} reference entr{'y' if len(uncited) == 1 else 'ies'} are never "
                f"cited (e.g. {sample}); every \\bibitem should be cited with \\cite.",
            ))
    return findings


def run_checks(tex_path: Path, bib_path: Path | None, citation_style: str = "venue") -> list[Finding]:
    raw = read_text(tex_path)
    text = strip_comments(raw)
    bib_keys = parse_bib_keys(bib_path)
    findings: list[Finding] = []
    findings.extend(check_document_markers(text))
    findings.extend(check_serialized_commands(text))
    findings.extend(check_merge_markers(text))
    findings.extend(check_braces(text))
    findings.extend(check_environments(text))
    findings.extend(check_labels_and_refs(text))
    findings.extend(check_citations(text, bib_keys, bib_path is not None))
    findings.extend(check_internal_destinations(text))
    findings.extend(check_graphics(text, tex_path))
    findings.extend(check_placeholders(text))
    findings.extend(check_alignment_tabs(text))
    findings.extend(check_title_and_maketitle(text))
    findings.extend(check_citation_format(text, citation_style))
    findings.extend(check_citation_linkage(text, bib_keys))
    return findings


def render_markdown(tex_path: Path, bib_path: Path | None, findings: list[Finding]) -> str:
    errors = [item for item in findings if item.severity == "error"]
    warnings = [item for item in findings if item.severity == "warning"]
    lines = ["# LaTeX Guard Report", ""]
    lines.append(f"- TeX file: `{tex_path}`")
    lines.append(f"- BibTeX file: `{bib_path}`" if bib_path else "- BibTeX file: not provided")
    lines.append(f"- Errors: {len(errors)}")
    lines.append(f"- Warnings: {len(warnings)}")
    lines.append("")
    if findings:
        lines.append("| Severity | Check | Line | Message |")
        lines.append("|---|---|---:|---|")
        for item in findings:
            line = "" if item.line is None else str(item.line)
            message = item.message.replace("|", "\\|")
            lines.append(f"| {item.severity} | {item.check} | {line} | {message} |")
    else:
        lines.append("No guard issues found.")
    lines.append("")
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Run structural guard checks for a LaTeX manuscript.")
    parser.add_argument("tex", type=Path, help="Main .tex file.")
    parser.add_argument("--bib", type=Path, help="Optional .bib file for citation-key checks.")
    parser.add_argument("--citation-style", choices=("venue", "numeric-brackets"), default="venue",
                        help="Preserve the selected venue's style by default; check bracket-specific formatting only when that convention is verified.")
    parser.add_argument("--json", action="store_true", help="Emit JSON.")
    parser.add_argument("--markdown", action="store_true", help="Emit Markdown (default).")
    args = parser.parse_args(argv)

    if not args.tex.exists():
        print(f"TeX file not found: {args.tex}", file=sys.stderr)
        return 2
    if args.bib and not args.bib.exists():
        print(f"BibTeX file not found: {args.bib}", file=sys.stderr)
        return 2

    findings = run_checks(args.tex.resolve(), args.bib.resolve() if args.bib else None, args.citation_style)
    if args.json:
        print(json.dumps([asdict(item) for item in findings], indent=2, ensure_ascii=False))
    else:
        print(render_markdown(args.tex.resolve(), args.bib.resolve() if args.bib else None, findings), end="")

    return 1 if any(item.severity == "error" for item in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
